clc,clear

load data5_after_fea_selection_train100class8_isp_basedonCENvalues
num_class =8;
num_fea =15;
A1=mytest;
E1=mytrain;
Center=Cen1;
k=num_class;
MaxLengthCycle=4; % Max cycle size 
% Note: MAxLengthCycle=2 is equivalent to TAN


for i=1:num_class
    num_train_vec(i,1)=sum(E1(:,end)==i); % a vector with size num_class*1 that its elements are the number of training data per class
end

%% part 1
CostMatrix1=zeros(num_fea,num_fea);
a=1;
for i=1:num_fea
    i
    for j=1:num_fea
        if i>=j   % Ip is symmetric
            h(a,1)=i; h(a,2)=j;h(a,3)=-1; % in order to remove redundant mutual infs
        else
            h(a,1)=i;h(a,2)=j;h(a,3)=condmutualinfo(E1(:,i),Center{1,1}{1,i},E1(:,j),Center{1,1}{1,j},E1(:,num_fea+1),Center{1,1}{1,num_fea+1},num_class);

        end
        a=a+1;
    end
end

% sorting operation and removing redundant mutual infs
h1=sortrows(h,-3);
vv=find(h1(:,end)~=-1);
h1(length(vv)+1:end,:)=[];


% forming adjacency matrix with respect to given maximum length cycle
adjMat=zeros(num_fea,num_fea);
%p=1;
for i=1:size(h1,1)

    adjMat(h1(i,1),h1(i,2))=1;
    adjMat(h1(i,2),h1(i,1))=1;
    [cyc,ti]=cycleCountBacktrack('adjMatrix',adjMat);
    if sum(cyc((MaxLengthCycle-1):end))>0
        adjMat(h1(i,1),h1(i,2))=0;
        adjMat(h1(i,2),h1(i,1))=0;
    end
end


%drawing the graph
[tot_cyc,~]=cycleCountBacktrack('adjMatrix',adjMat);

%checking the decomposablity of the graph
%isDecomposable=isDecomposableG(adjMat)


[tot_cyc,~]=cycleCountBacktrack('adjMatrix',adjMat);



% finding cliques (clusters) of graph
clique_Mat=maximalCliques(adjMat,'v2')

[~,num_clus]=size(clique_Mat); % num_clus is the number of cliques

% finding cardinality of the seperators
for i=1:num_clus
    for j=1:num_clus
        if i~=j
            cardinality_sep_Mat(i,j)=sum(clique_Mat(:,i).*clique_Mat(:,j));
        end
    end
end


% finding maximum spanning tree with respect to matrix of cardinality of the seperators
[ Tree,~ ]=UndirectedMaximumSpanningTree (cardinality_sep_Mat);



% finding seperators
[r,c]=find(Tree==1);
sep_set=[];
for i=1:length(r)
    k1=1;
    vec1=[];
    vec1=find(clique_Mat(:,r(i))==clique_Mat(:,c(i))); % finding
    x=find(clique_Mat(:,c(i))~=0);
    ro=size(sep_set,1)+1;
    for j=1:length(x)
        if sum(vec1==x(j))~=0

            sep_set(ro,k1)=x(j);
            k1=k1+1;
        end
    end
    for l=1:(size(sep_set,1)-1)
        if sum(sep_set(end,:)~=sep_set(l,:))==0
            sep_set(end,:)=[]
            break
        end
    end
end




for i=1:size(sep_set,1)
    vec2=find(sep_set(i,:)~=0);
    s1=0;
    for j=1:num_clus
        for l1=1:length(vec2)
            if clique_Mat(sep_set(i,vec2(l1)),j)~=1
                ind=0;
                break
            else
                ind=1;
            end
        end
        if ind==1
            s1=s1+1;
        end
    end
    sep_rep(i)=s1;
end

clus=zeros(num_clus,MaxLengthCycle);
for i=1:num_clus
    vec3=find(clique_Mat(:,i)==1);
    clus(i,1:length(vec3))=vec3;
end

sep=sep_set;
num_sep=size(sep_set,1);


[m,n]=size(A1); % A1:test data

Pr_clus1=zeros(m,num_clus,num_class); %the probability of clusters
Pr_sep1=zeros(m,num_sep,num_class); %the probability of seperators
for d=1:m % d is index of test samples
    d
    for i=1:num_class % i is index if classes
        mat1=[];
        xx=find(E1(:,end)==i);
        mat1=E1(xx,:);
        for k=1:num_clus % k is index of clusters
            num_var1=sum(clus(k,:)~=0);
            mat2=[];p2=[];mat3=[];p3=[];mat4=[];p4=[];mat5=[];p5=[];

            if num_var1==5
              
                p1=find(mat1(:,clus(k,1))==A1(d,clus(k,1)));
                mat2=mat1(p1,:);
                p2=find(mat2(:,clus(k,2))==A1(d,clus(k,2)));
                mat3=mat2(p2,:);
                p3=find(mat3(:,clus(k,3))==A1(d,clus(k,3)));
                mat4=mat3(p3,:);
                p4=find(mat4(:,clus(k,4))==A1(d,clus(k,4)));
                mat5=mat4(p4,:);
                p5=find(mat5(:,clus(k,5))==A1(d,clus(k,5)));
                Pr_clus1(d,k,i)=length(p5);

            end
            if num_var1==4
               
                p1=find(mat1(:,clus(k,1))==A1(d,clus(k,1)));
                mat2=mat1(p1,:);
                p2=find(mat2(:,clus(k,2))==A1(d,clus(k,2)));
                mat3=mat2(p2,:);
                p3=find(mat3(:,clus(k,3))==A1(d,clus(k,3)));
                mat4=mat3(p3,:);
                p4=find(mat4(:,clus(k,4))==A1(d,clus(k,4)));
                Pr_clus1(d,k,i)=length(p4);
            end


            if num_var1==3
                 p1=find(mat1(:,clus(k,1))==A1(d,clus(k,1)));
                mat2=mat1(p1,:);
                p2=find(mat2(:,clus(k,2))==A1(d,clus(k,2)));
                mat3=mat2(p2,:);
                p3=find(mat3(:,clus(k,3))==A1(d,clus(k,3)));
                Pr_clus1(d,k,i)=length(p3);
            end

            if num_var1==2
                vec_var1=find(clus(k,:)~=0);
                p1=find(mat1(:,clus(k,vec_var1(1)))==A1(d,clus(k,vec_var1(1))));
                mat2=mat1(p1,:);
                p2=find(mat2(:,clus(k,vec_var1(2)))==A1(d,clus(k,vec_var1(2))));
                Pr_clus1(d,k,i)=length(p2);
            end


            if num_var1==1
                vec_var1=find(clus(k,:)~=0);
                 p1=find(mat1(:,clus(k,vec_var1(1)))==A1(d,clus(k,vec_var1(1))));
                Pr_clus1(d,k,i)=length(p1);
            end
        end


        %
        %
        mat2=[];p2=[];mat3=[];p3=[];mat4=[];p4=[];
        %             %%%% seperators
        for l=1:num_sep % l is index of seperators
            num_var2=sum(sep(l,:)~=0);

            if num_var2==4
                p1=find(mat1(:,sep(l,1))==A1(d,sep(l,1)));
                mat2=mat1(p1,:);
                p2=find(mat2(:,sep(l,2))==A1(d,sep(l,2)));
                mat3=mat2(p2,:);
                p3=find(mat3(:,sep(l,3))==A1(d,sep(l,3)));
                mat4=mat3(p3,:);
                p4=find(mat4(:,sep(l,4))==A1(d,sep(l,4)));
                Pr_sep1(d,l,i)=length(p4);
            end



            if num_var2==3
                 p1=find(mat1(:,sep(l,1))==A1(d,sep(l,1)));
                mat2=mat1(p1,:);
                p2=find(mat2(:,sep(l,2))==A1(d,sep(l,2)));
                mat3=mat2(p2,:);
                p3=find(mat3(:,sep(l,3))==A1(d,sep(l,3)));
                Pr_sep1(d,l,i)=length(p3);
            end




            if num_var2==2
                 p1=find(mat1(:,sep(l,1))==A1(d,sep(l,1)));
                mat2=mat1(p1,:);
                p2=find(mat2(:,sep(l,2))==A1(d,sep(l,2)));
                Pr_sep1(d,l,i)=length(p2);
            end

            if num_var2==1
                vec_var2=find(sep(l,:)~=0);
                 p1=find(mat1(:,sep(l,1))==A1(d,sep(l,1)));
                Pr_sep1(d,l,i)=length(p1);
            end
        end

        temp2=Pr_clus1(d,:,i)==0;
        Pr_clus1(d,:,i)=Pr_clus1(d,:,i)+temp2.*(10^(-15));
        Pr_clus1(d,:,i)=Pr_clus1(d,:,i);
        %(1/num_train_vec(i))*
        Pr_sep1(d,:,i)=Pr_sep1(d,:,i);
        %(1/num_train_vec(i))*
    end
end
% % %
% %
% %
ff=num_clus-(sum(sep_rep)-num_sep);
for j=1:num_class
    AA(:,j)=Pr_clus1(:,1,j);
    dd(:,j)=Pr_sep1(:,1,j).^(sep_rep(1)-1);
    for i=2:num_clus
        AA(:,j)=AA(:,j).*Pr_clus1(:,i,j);
    end
    for s=2:num_sep
        dd(:,j)=dd(:,j).*(Pr_sep1(:,s,j).^(sep_rep(s)-1));
    end
    p=find(dd(:,j)==0);
    q=find(dd(:,j)~=0);
    WW(p,j)=-1;
    WW(q,j)=AA(q,j)./(dd(q,j)*(num_train_vec(j)^ff));
end
%num_train_vec=[1000,1000,15000,100,200,5000,10000,100];
for i=1:num_class
    WW1(:,i)=(num_train_vec(i)/sum(num_train_vec))*WW(:,i);
end

[val,II]=max(WW1,[],2);
[AUC,TRUST]=metric_per_class(num_class,A1,II)
Auc_ave= sum(AUC)/num_class
Trust_ave = sum(TRUST)/num_class
% % % %
F=(2*AUC.*TRUST)./(AUC+TRUST)
